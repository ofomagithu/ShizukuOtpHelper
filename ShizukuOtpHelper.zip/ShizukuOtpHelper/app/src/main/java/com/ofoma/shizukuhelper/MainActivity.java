package com.ofoma.shizukuhelper;

import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import rikka.shizuku.Shizuku;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE = 1234;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!Shizuku.pingBinder()) {
            Toast.makeText(this, "Shizuku not running. Start it first!", Toast.LENGTH_LONG).show();
            return;
        }

        if (!Shizuku.isPreV11() && Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            Shizuku.requestPermission(REQUEST_CODE);
        } else {
            runPermissionGrant();
        }
    }

    private void runPermissionGrant() {
        try {
            String pkg = getPackageName();
            String cmd = "appops set " + pkg + " RECEIVE_SMS allow";
            Process p = Shizuku.newProcess(new String[]{"sh", "-c", cmd});
            Toast.makeText(this, "Permissions granted via Shizuku", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
