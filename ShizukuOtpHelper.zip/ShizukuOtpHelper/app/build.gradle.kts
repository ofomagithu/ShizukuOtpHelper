plugins {
    id 'com.android.application'
}

android {
    compileSdkVersion 33
    defaultConfig {
        applicationId "com.ofoma.shizukuhelper"
        minSdkVersion 23
        targetSdkVersion 33
        versionCode 1
        versionName "1.0"
    }
    buildTypes {
        release {
            minifyEnabled false
        }
    }
    namespace 'com.ofoma.shizukuhelper'
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'dev.rikka.shizuku:api:12.1.0'
}
